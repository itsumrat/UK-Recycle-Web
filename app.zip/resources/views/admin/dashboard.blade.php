@extends('admin.layouts.app')
@section('content')
    <div class="row">
    </div>
@endsection
