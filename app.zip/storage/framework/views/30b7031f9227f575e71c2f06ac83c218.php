<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>

    <body>
        <table id="deliveryOutTable" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Category</th>
                    <th>Measurement Type</th>
                    <th>Case</th>
                    <th>Quantity</th>
                    <th>Added</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $deleveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value->delivery->delivery_out_id); ?>/ <?php echo e(++$key); ?></td>
                        <td><?php echo e($value->date); ?></td>
                        <td><?php echo e(!empty($value->category) ? $value->category->name : ''); ?></td>
                        <td><?php echo e(!empty($value->measurements) ? $value->measurements->name : ''); ?></td>
                        <td><?php echo e(!empty($value->cage) ? $value->cage->case_name : ''); ?></td>
                        <td><?php echo e($value->product_weight); ?></td>
                        <td><?php echo e(!empty($value->user) ? $value->user->name : ''); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>

</html><?php /**PATH F:\xampp\htdocs\uk_recycling\resources\views/admin/delivery-out/exports/sub_index.blade.php ENDPATH**/ ?>