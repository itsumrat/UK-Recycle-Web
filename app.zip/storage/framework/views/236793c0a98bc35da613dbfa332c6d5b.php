
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="card card-user">
      <div class="card-header">
        <h5 class="card-title">Add Delivery Out</h5>
      </div>
      <div class="card-body">
        <form method="POST" action="<?php echo e(route('delivery-out.store')); ?>">

          <?php echo csrf_field(); ?>
          <div class="form-row">
            <div class="col">
              <label>ID</label>
              <input type="text" class="form-control" value="<?php echo e($latstId); ?>/day-month-year/Customer" readonly>
            </div>
            <div class="col">
              <label>Customer</label>
              <select class="customerName form-control" name="customer_id">
                <option>Select One</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col">
              <label class="form-label">Assigned to</label>
              <select name="assigned_to" class="usersName form-control">
                <option>Select</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="form-row mt-3">
            
            <div class="col">
              <label>Delivery Type</label>
              <select class="form-control" name="delivery_type">
                <option>Select</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col">
              <label>Measurement</label>
              <select class="form-control" name="measurement_type">
                <option>Select</option>
                <?php $__currentLoopData = $measurement_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="update ml-auto mr-auto">
            <button type="submit" class="btn btn-primary btn-round">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="card ">
      <div class="card-header ">
        <div class="row">
            <h5 class="card-title col">Delivery Out</h5>
            <div class="col-3 text-right">
                <div id="reportrange" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc;">
                    <i class="fa fa-calendar"></i>&nbsp;<span></span> <i class="fa fa-caret-down"></i>
                </div>
                <button id="exportBtn" class="btn btn-primary">Export to CSV</button>
                
            </div>
        </div>
        
      </div>
        
      <div class="card-body ">
        <table id="deliveryOutTable" class="display">
          <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Customer</th>
                <th>Measurement Type</th>
                <th>Pallet</th>
                <th>Case</th>
                <th>Piece</th>
                <th>Assigned To</th>
                <th>Added</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>

                <td>
                    <a href="#" class="view-transactions" data-delivery-id="<?php echo e($value->id); ?>">
                        <?php echo e($value->delivery_out_id); ?>/<?php echo e(date('d-m-y', strtotime($value->date))); ?>/
                        <?php echo e(!empty($value->customer) ? $value->customer->name : ''); ?> /<?php echo e(optional($value->measurement)->name ?? ''); ?>

                    </a>
                </td>
              <td><?php echo e($value->date); ?></td>
              <td><?php echo e(optional($value->customer)->name ?? ''); ?></td>
              <td><?php echo e(optional($value->measurement)->name ?? ''); ?></td>
              <?php if($value->measurement->name == 'Pallet'): ?>
              <td><?php echo e($value->trx->sum('weight') ?? ''); ?></td>
              <?php else: ?>
              <td></td>
              <?php endif; ?>
              <?php if($value->measurement->name == 'Cage'): ?>
              <td><?php echo e($value->trx->sum('weight') ?? ''); ?></td>
              <?php else: ?>
              <td></td>
              <?php endif; ?>
              <?php if($value->measurement->name == 'Piece'): ?>
              <td><?php echo e($value->trx->sum('weight') ?? ''); ?></td>
              <?php else: ?>
              <td></td>
              <?php endif; ?>
              <td><?php echo e(optional($value->assignedTo)->name ?? ''); ?></td>
              <td><?php echo e(optional($value->user)->name ?? ''); ?></td>
              <td>
              <a href="javascript:void(0)" data-toggle="tooltip" data-id="<?php echo e($value->id); ?>" data-original-title="Edit" class="edit pr-2  editDoutData">
                  <i class="nc-icon nc-tag-content"></i>
                </a>
                <a href="javascript:void(0)" data-toggle="tooltip" data-id="<?php echo e($value->id); ?>" class="deleteDoutData"><i class="nc-icon nc-basket"></i></a>
              
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="card ">
      <div class="card-header">
        <div class="row">
            <div class="col">
                <h5 class="card-title" id="din-trx-title"></h5>
            </div>
            <div class="col-3 text-right">
                <a class="download btn btn-primary " id="exportBtn">Export to CSV</a>
                
            </div>
        </div>

    </div>
      <div class="card-body ">
        <table id="transactionOutTable" class="display">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Category</th>
              <th>Measurement Type</th>
              <th>Case</th>
              <th>Quantity</th>
              <th>Added</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Case List Modal -->
<div class="modal fade" id="caseModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="caseEditForm" name="caseEditForm" class="form-horizontal">
          <div class="modal-body">
            <input type="hidden" id="case_id" name="id" value="">
            <div class="row">
              <label>Customer</label>
              <select class="customerName form-control" id="customer_id" name="customer_id">
                <option>Select One</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="row pt-2">
              <label class="form-label">Assigned to</label>
              <select name="assigned_to" class="usersName form-control" id="assigned_to">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="row pt-2">
              <label>Product Category</label>
              <select class="productName form-control" name="category_id" id="category_id">
                <option>Select One</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="row pt-2">
              <label>Delivery Type</label>
              <select class="form-control" name="delivery_type" id="delivery_type">
                <option>Select</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="row pt-2">
              <label>Measurement</label>
              <select class="form-control" name="measurement_type" id="measurement_type">
                <option>Select</option>
                <?php $__currentLoopData = $measurement_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="caseSaveBtn">Save changes</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function() {
    $('.view-transactions').on('click', function(e) {
      e.preventDefault();
      var deliveryId = $(this).data('delivery-id');
      var transactionsTable = $('#transactionOutTable'); // Assuming you have a table with id="transactions-table"
      var dinTrxTitle = $('#din-trx-title');

      $.ajax({
        url: '<?php echo e(url("/delivery-out/")); ?>/' + deliveryId,
        type: 'GET',
        success: function(response) {
          console.log(response);
          // Clear existing table rows
          transactionsTable.find('tbody').empty();

          $('.download').attr('href', 'delivery-out/' + deliveryId+'?download=csv')
          let i = 1;

          // Populate the table with the new transactions
          $.each(response.transactions, function(index, transaction) {
            // var cage = transaction.cage.case_name ? transaction.cage.case_name : 'N/A';
            // var cage = transaction.cage.case_name !== undefined && transaction.cage.case_name !== null
            //       ? transaction.cage.case_name
            //       : 'N/A';
                  var createdAtDate = new Date(transaction.date);
      var formattedDate = createdAtDate.toISOString().split('T')[0];
            transactionsTable.find('tbody').append(`
                            <tr>
                                <td>${transaction.delivery.delivery_out_id}/${i}</td>
                                <td>${formattedDate}</td>
                                <td>${transaction.category?.name }</td>
                                <td>${transaction.measurements.name}</td>
                                <td>${transaction.cage?.case_name ?? 'N/A'}</td>
                                <td>${transaction.product_weight}</td>
                                <td>${transaction.user.name}<br><span class="badge badge-info">${transaction.user.uid}</span></td>
                                <td>
                          <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                          <a href="#"><i class="nc-icon nc-basket"></i></a>
                        </td>
                            </tr>
                        `);
                        dinTrxTitle.text(`Transactions of ${transaction.delivery.delivery_out_id}`);
                        i++;
          });
        },
        error: function(error) {
          console.error(error);
        }
      });
    });
  });

      //Case List
      $(document).on('click', 'a.editDoutData', function() {
    var id = $(this).data('id');
    let url = "<?php echo e(route('delivery-out.edit', ':id')); ?>";
    $.ajax({
      type: 'GET',
      url: url.replace(':id', id),
      success: function(data) {
        //console.log(data);
        $('#caseModal').modal('show');
        $('#case_id').val(data.data.id);
        $('#customer_id').val(data.data.customer_id);
        $('#assigned_to').val(data.data.assigned_to);
        $('#category_id').val(data.data.category_id);
        $('#delivery_type').val(data.data.delivery_type);
        $('#measurement_type').val(data.data.Measurement_type);
      }
    });
  });

  $('body').on('click', '#caseSaveBtn', function(event) {
    event.preventDefault()
    var id = $("#case_id").val();
    var customer_id = $("#customer_id").val();
    var category_id = $("#category_id").val();
    var assigned_to = $("#assigned_to").val();
    var delivery_type = $("#delivery_type").val();
    var measurement_type = $("#measurement_type").val();
    let url = "<?php echo e(route('delivery-out.update', ':id')); ?>";
    $.ajax({
      url: url.replace(':id', id),
      type: "POST",
      data: {
        'id': id,
        'customer_id': customer_id,
        'category_id': category_id,
        'assigned_to': assigned_to,
        'delivery_type': delivery_type,
        'measurement_type': measurement_type,
        '_token': '<?php echo e(csrf_token()); ?>',
      },
      dataType: 'json',
      success: function(data) {
        $('#caseEditForm').trigger("reset");
        $('#caseModal').modal('hide');
        return location.reload();
      }
    });
  });

  $('body').on('click', '.deleteDoutData', function() {
    let id = $(this).data('id');

    let confirmData = confirm("Are you confirm to delete this data!");

    if (confirmData == true) {
      $.ajax({
        method: "get",
        url: "<?php echo e(url('delivery-out')); ?>/" + id + '/delete',
        success: function(res) {
          return location.reload();
        },
        error: function(xhr) {
          console.log("error");
        }
      });
    }

  });

  // Handle Export button click
$('#exportBtn').click(function() {
    var dateRange = $('#reportrange').find('span').text();
    var startDate = dateRange.split(' - ')[0];
    var endDate = dateRange.split(' - ')[1];
    
    if (startDate && endDate) {
        $.ajax({
            url: "deliveryOutCsv", // Replace with the correct URL for your "attendant" route
            type: 'GET',
            data: {
                start_date: startDate,
                end_date: endDate
            },
            success: function(response) {
                // Create a hidden anchor element
                var link = document.createElement('a');
                link.href = window.URL.createObjectURL(new Blob([response]));
                link.setAttribute('download', 'delivery_out_csv.csv');

                // Trigger the download
                document.body.appendChild(link);
                link.click();

                // Cleanup
                document.body.removeChild(link);
            },
            error: function(xhr, status, error) {
                // Handle the error response here
                console.error(xhr.responseText);
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\uk_recycling\resources\views/admin/delivery-out/index.blade.php ENDPATH**/ ?>