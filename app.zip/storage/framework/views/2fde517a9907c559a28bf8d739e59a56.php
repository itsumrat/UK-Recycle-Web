<div class="sidebar" data-color="white" data-active-color="danger">
    <div class="logo">
        <a href="#" class="simple-text logo-mini">
            <div class="logo-image-small">
                <img src="<?php echo e(asset('assets/img/logo-square.png')); ?>">
            </div>
            <!-- <p>CT</p> -->
        </a>
        <a href="#" class="simple-text logo-normal">
            UK Textiles
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dashboard.index')); ?>">
                    <i class="nc-icon nc-shop"></i>
                    <p>Home</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('delivery-in') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('delivery-in.index')); ?>">
                    <i class="nc-icon nc-tile-56"></i>
                    <p>Delivery In</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('delivery-out') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('delivery-out.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Delivery Out</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('production-setup') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('production-setup.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Production Setup</p>
                </a>
            </li>
            <li>
            </li>
            <li class="<?php echo e(request()->is('productions') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('productions.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Production</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('customers') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('customers.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Customer</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('suppliers') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('suppliers.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Supplier</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('attendances') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('attendances.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Attendance</p>
                </a>
            </li>
            <li class="<?php echo e(request()->is('users') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('users.index')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p>Users</p>
                </a>
            </li>

            <li class="">
                <a href="#">
                    <i class="nc-icon nc-chart-bar-32"></i>
                    <p>Reports</p>
                </a>
                <ul>
                    
                    <li class="<?php echo e(request()->is('report/customer') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/report/customer')); ?>">
                            <i class="nc-icon nc-cart-simple"></i>
                            <p>Customer</p>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->is('report/supplier') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/report/supplier')); ?>">
                            <i class="nc-icon nc-cart-simple"></i>
                            <p>Supplier</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="">
                <a href="#">
                    <i class="nc-icon nc-app"></i>
                    <p>Stock</p>
                </a>
                <ul>
                    <li class="<?php echo e(request()->is('stock/delivery_in') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/stock/delivery_in')); ?>">
                            <i class="nc-icon nc-cloud-download-93"></i>
                            <p>Delivery In</p>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->is('stock/delivery_out') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/stock/delivery_out')); ?>">
                            <i class="nc-icon nc-cloud-upload-94"></i>
                            <p>Delivery Out</p>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->is('stock') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/stock')); ?>">
                            <i class="nc-icon nc-chart-pie-36"></i>
                            <p>Stock</p>
                        </a>
                    </li>
                </ul>
            </li>

        </ul>
    </div>
</div><?php /**PATH F:\xampp\htdocs\uk_recycling\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>