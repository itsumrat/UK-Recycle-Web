
<?php $__env->startSection('content'); ?>
    <div class="row">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\uk_recycling\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>