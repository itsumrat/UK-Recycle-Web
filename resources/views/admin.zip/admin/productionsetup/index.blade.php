@extends('admin.layouts.app')
@section('title')
@endsection
@section('content')
<div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title">Add Case</h5>
              </div>
              <div class="card-body">
              <form method="POST" action="{{ route('cases.store') }}">

                @csrf
                    <div class="form-group">
                      <label>Case</label>
                      <input type="text" name="case_name" class="form-control" placeholder="Case">
                    </div>
                    <div class="form-group">
                      <label>Weight (KG)</label>
                      <input type="text" name="weight" class="form-control" placeholder="Weight">
                    </div>
                    <div class="update ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Submit</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Case List</h5>
              </div>
              <div class="card-body ">
                <table id="caseTable" class="display">
                  <thead>
                      <tr>
                          <th>ID/Name</th>
                          <th>Weight (KG)</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  @foreach ($cases as $key=>$value)
                      <tr>
                          <td>{{$value->case_name}}</td>
                          <td>{{$value->weight}}</td>
                          <td>
                            <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                            <a href="#"><i class="nc-icon nc-basket"></i></a>
                          </td>
                      </tr>
                      @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title">Add Table</h5>
              </div>
              <div class="card-body">
              <form method="POST" action="{{ route('tables.store') }}">
                @csrf
                    <div class="form-group">
                      <label>ID</label>
                      <input type="text" name="table_id" class="form-control" placeholder="Table ID">
                    </div>
                    <div class="form-group">
                      <label>Name</label>
                      <input type="text" name="name" class="form-control" placeholder="Table name">
                    </div>
                    <div class="update ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Submit</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Table List</h5>
              </div>
              <div class="card-body ">
                <table id="tableList" class="display">
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  @foreach ($tables as $key=>$value)

                      <tr>
                          <td>{{$value->table_id}}</td>
                          <td>{{$value->name}}</td>
                          <td>
                            <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                            <a href="#"><i class="nc-icon nc-basket"></i></a>
                          </td>
                      </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title">Add Grade</h5>
              </div>
              <div class="card-body">
              <form method="POST" action="{{ route('grades.store') }}">
                @csrf
                    <div class="form-group">
                      <label>ID</label>
                      <input type="text" name="grade_id" class="form-control" placeholder="Grade ID">
                    </div>
                    <div class="form-group">
                      <label>Name</label>
                      <input type="text" name="name" class="form-control" placeholder="Grade name">
                    </div>
                    <div class="form-group">
                      <label>Weight</label>
                      <input type="text" name="weight" class="form-control" placeholder="Grade weight">
                    </div>
                    <div class="ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Submit</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Grade List</h5>
              </div>
              <div class="card-body ">
                <table id="gradeList" class="display">
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Weight</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  @foreach ($grades as $key=>$value)

                      <tr>
                          <td>{{$value->grade_id}}</td>
                          <td>{{$value->name}}</td>
                          <td>{{$value->weight}}</td>
                          <td>
                            <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                            <a href="#"><i class="nc-icon nc-basket"></i></a>
                          </td>
                      </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title">Add Product Category</h5>
              </div>
              <div class="card-body">
              <form method="POST" action="{{ route('product-categories.store') }}">
                @csrf
                    <div class="form-group">
                      <label>ID</label>
                      <input type="text" name="category_id" class="form-control" placeholder="Category ID">
                    </div>
                    <div class="form-group">
                      <label>Name</label>
                      <input type="text" name="name" class="form-control" placeholder="Category name">
                    </div>
                    <div class="update ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Submit</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Product Category List</h5>
              </div>
              <div class="card-body ">
                <table id="prodCatTable" class="display">
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  @foreach ($cats as $key=>$value)

                      <tr>
                          <td>{{$value->category_id}}</td>
                          <td>{{$value->name}}</td>
                          <td>
                            <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                            <a href="#"><i class="nc-icon nc-basket"></i></a>
                          </td>
                      </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title">Delivery Type</h5>
              </div>
              <div class="card-body">
              <form method="POST" action="{{ route('delivery-types.store') }}">
                @csrf
                    <div class="form-group">
                      <label>ID</label>
                      <input type="text" name="delivery_type_id" class="form-control" placeholder="Delivery Type ID">
                    </div>
                    <div class="form-group">
                      <label>Name</label>
                      <input type="text" name="name" class="form-control" placeholder="Name">
                    </div>
                    <div class="update ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Submit</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Delivery Type List</h5>
              </div>
              <div class="card-body ">
                <table id="deliveryTypeTable" class="display">
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  @foreach ($types as $key=>$value)

                      <tr>
                          <td>{{$value->delivery_type_id}}</td>
                          <td>{{$value->name}}</td>
                          <td>
                            <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                            <a href="#"><i class="nc-icon nc-basket"></i></a>
                          </td>
                      </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
@endsection

