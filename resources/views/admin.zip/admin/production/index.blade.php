@extends('admin.layouts.app')
@section('title')
@endsection
@section('content')
<div class="row">
  <div class="col-lg-3 col-md-4 col-sm-12">
    <div class="card card-stats">
      <div class="card-body ">
        <h5>Production</h5>
        <form action="{{ route('productions.store') }}" method="post">
              @csrf
          <div class="mb-3">
            <label class="form-label">Date</label>
            <input type="date" name="production_date" class="form-control" name="productionDate">
          </div>
          <div class="mb-3">
            <label class="form-label">ID</label>
            <input type="text" name="production_id" class="form-control" placeholder="{{$pr ?: 'Production ID'}}">
          </div>
          <div class="mb-3">
            <label class="form-label">Assigned to by</label>
            <select name="assigned_to" class="usersName form-control">
            @foreach($users as $key=>$value)
                <option value="{{$key}}">{{$value->name}}</option>
            @endforeach

            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Table</label>
            <select name="table" class="tableName form-control">
            <option selected>Select</option>
            @foreach($tables as $key=>$value)
            <option value="{{$value->id}}">{{$value->name}}</option>
            @endforeach
            </select>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-9 col-md-8 col-sm-12">
    <div class="card ">
      <div class="card-header ">
        <h5 class="card-title">Production List</h5>
      </div>
      <div class="card-body ">
        <table id="productionTable" class="display">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Table</th>
              <th>Staff</th>
              <th>Weight</th>
              <th>Grade</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          @foreach($data as $key=>$value)

            <tr>
              <td>{{$value->production_id}}/Date/Staff/Table</td>
              <td>{{$value->production_date}}</td>
              <td>{{$value->tables->name}}</td>
              <td>{{$value->assignedTo->name}}</td>
              <td></td>
              <td></td>
              <td>
                <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                <a href="#"><i class="nc-icon nc-basket"></i></a>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection