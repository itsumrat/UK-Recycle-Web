@extends('admin.layouts.app')
@section('title')
@endsection
@section('content')
<div class="row">
      <div class="col-md-3">
        <div class="card card-user">
          <div class="card-header">
            <h5 class="card-title">Add Supplier</h5>
          </div>
          <div class="card-body">
          <form method="POST" action="{{ route('suppliers.store') }}">

@csrf
              <div class="form-group">
                <label>ID</label>
                <input type="text" class="form-control" value="{{$sup}}" readonly>
              </div>
              <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control" placeholder="Supplier name">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Email">
              </div>
              <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" name="address" placeholder="Address"></textarea>
              </div>
              <div class="update ml-auto mr-auto">
                <button type="submit" class="btn btn-primary btn-round">Save</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="col-lg-9 col-md-9 col-sm-12">
        <div class="card">
          <div class="card-header ">
            <h5 class="card-title">Supplier List</h5>
          </div>
          <div class="card-body ">
            <table id="userTable" class="display">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Company</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @foreach($suppliers as $key=>$value)
                        <tr>
                            <td>{{$value->supplier_id}}</td>
                            <td>{{$value->name}} </td>
                            <td>{{$value->email}}</td>
                            <td>{{$value->address}}</td>
                            <td>{{ \Carbon\Carbon::parse($value->created_at)->format('Y-m-d') }}</td>
                            <td>
                                <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                                <a href="#"><i class="nc-icon nc-basket"></i></a>
                            </td>
                        </tr>
                        @endforeach

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
@endsection