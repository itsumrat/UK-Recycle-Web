@extends('admin.layouts.app')
@section('title')
@endsection
@section('content')
@if(count($errors) > 0)
    <div class="row">
        <div class="col-md-8">            
            <div class="alert alert-danger">
                @foreach ($errors->all() as $error)
                    <div>{{ $error }}</div>
                @endforeach
            </div>
        </div>
    </div>
    @endif
    @if ($message = Session::get('error'))
                <div class="alert alert-warning">
                    <p>{{ $message }}</p>
                </div>
            @endif
<div class="row">
    <div class="col-md-12">
        <div class="card card-user">
            <div class="card-header">
                <h5 class="card-title">Add Users</h5>
            </div>
            <div class="card-body">
            <form action="{{ route('users.store') }}" method="post">
                    @csrf
            <div class="form-row">
                        <div class="col">
                            <label class="form-label">User Type</label>
                            <select name="user_type" class="form-select form-control">
                                <option selected>Select</option>
                                @foreach($types as $key=>$value)
                                <option value="{{$key}}">{{$value}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col">
                            <label>ID</label>
                            <input type="text" class="form-control" value="SUP-0001">
                        </div>
                    </div>
                    <div class="form-row mt-3">
                        <div class="col">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Full Name">
                        </div>
                        <div class="col">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Email">
                        </div>
                        <div class="col">
                            <label>Password</label>
                            <input type="input" name="password" class="form-control" placeholder="Email">
                        </div>
                    </div>
                    <div class="form-row mt-3">
                        <div class="col">
                            <label>Address</label>
                            <textarea name="address" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="update ml-auto mr-auto">
                        <button type="submit" class="btn btn-primary btn-round">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card ">
            <div class="card-header ">
                <h5 class="card-title">User List</h5>
            </div>
            <div class="card-body ">
                <table id="userTable" class="display">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($users as $key=>$value)
                        <tr>
                            <td>{{$value->user_id}}</td>
                            <td>{{$value->name}}<br><span class="badge badge-info">{{ \App\Models\Util::getUserTypes($value->user_type)}}</span></td>
                            <td>{{$value->email}}</td>
                            <td>{{$value->address}}</td>
                            <td>{{ \Carbon\Carbon::parse($value->created_at)->format('Y-m-d') }}</td>
                            <td>
                                <a href="#" class="pr-2"><i class="nc-icon nc-tag-content"></i></a>
                                <a href="#"><i class="nc-icon nc-basket"></i></a>
                            </td>
                        </tr>
                        @endforeach
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection